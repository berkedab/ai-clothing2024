
## Some scripts for developers to use, include:

- `run_instant_tests.sh`: run training for a few iterations.
- `run_inference_tests.sh`: run inference on a small dataset.
- `../../dev/linter.sh`: lint the codebase before commit
- `../../dev/parse_results.sh`: parse results from log file.
