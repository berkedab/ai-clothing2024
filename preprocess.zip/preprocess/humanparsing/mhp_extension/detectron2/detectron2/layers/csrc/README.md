

To add a new Op:

1. Create a new directory
2. Implement new ops there
3. Delcare its Python interface in `vision.cpp`.
